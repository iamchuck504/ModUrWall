import 'package:flutter/material.dart';
import 'dart:math' as math;

void main() {
  runApp(const ModUrWallApp());
}

class ModUrWallApp extends StatelessWidget {
  const ModUrWallApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ModUrWall',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isDarkMode = true;
  Color _accentColor = const Color(0xFFa01030); // Red wine por defecto

  final List<Color> _themeColors = [
    const Color(0xFFa01030), // Red wine
    const Color(0xFF4a7dff), // Blue ocean
    const Color(0xFFff1493), // Fusion
    const Color(0xFFff6b35), // Solar orange
  ];

  final List<String> _themeNames = [
    'Wine',
    'Ocean',
    'Fusion',
    'Orange',
  ];

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  void _changeAccentColor(Color color) {
    setState(() {
      _accentColor = color;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _isDarkMode ? Colors.black : const Color(0xFFF5F5F5),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: _isDarkMode ? const Color(0xFF333333) : const Color(0xFFDDDDDD),
                    width: 1,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'MODURUWALL',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w300,
                      letterSpacing: 4,
                      color: _isDarkMode ? Colors.white : Colors.black,
                      fontFamily: 'Courier',
                    ),
                  ),
                  Row(
                    children: [
                      // Theme buttons
                      ...List.generate(_themeColors.length, (index) {
                        bool isActive = _accentColor == _themeColors[index];
                        return Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: GestureDetector(
                            onTap: () => _changeAccentColor(_themeColors[index]),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    _themeColors[index].withOpacity(0.8),
                                    _themeColors[index],
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(4),
                                boxShadow: isActive
                                    ? [
                                        BoxShadow(
                                          color: _themeColors[index].withOpacity(0.5),
                                          blurRadius: 15,
                                          spreadRadius: 2,
                                        ),
                                      ]
                                    : [],
                              ),
                              child: Text(
                                _themeNames[index].toUpperCase(),
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: Colors.white,
                                  letterSpacing: 1.5,
                                  fontFamily: 'Courier',
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                      const SizedBox(width: 8),
                      // Dark/Light mode toggle
                      GestureDetector(
                        onTap: _toggleTheme,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF444444), Color(0xFF666666)],
                            ),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Icon(
                            _isDarkMode ? Icons.light_mode : Icons.dark_mode,
                            size: 16,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Search bar
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: _isDarkMode ? const Color(0xFF222222) : const Color(0xFFE0E0E0),
                    width: 1,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'BUSCAR DISEÑO',
                    style: TextStyle(
                      fontSize: 11,
                      letterSpacing: 2,
                      color: _accentColor,
                      fontFamily: 'Courier',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    style: TextStyle(
                      color: _isDarkMode ? Colors.white : Colors.black,
                      fontFamily: 'Courier',
                    ),
                    decoration: InputDecoration(
                      hintText: 'Describe tu wallpaper ideal...',
                      hintStyle: TextStyle(
                        color: (_isDarkMode ? Colors.white : Colors.black).withOpacity(0.4),
                      ),
                      border: InputBorder.none,
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: _isDarkMode ? const Color(0xFF333333) : const Color(0xFFDDDDDD),
                        ),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: _accentColor, width: 2),
                      ),
                      suffixIcon: Icon(Icons.search, color: _accentColor),
                    ),
                  ),
                ],
              ),
            ),

            // Gallery grid
            Expanded(
              child: WallpaperGallery(
                accentColor: _accentColor,
                isDarkMode: _isDarkMode,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WallpaperGallery extends StatelessWidget {
  final Color accentColor;
  final bool isDarkMode;

  const WallpaperGallery({
    super.key,
    required this.accentColor,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(24),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 0.7,
      ),
      itemCount: 9,
      itemBuilder: (context, index) {
        return GalleryItem(
          index: index,
          accentColor: accentColor,
          isDarkMode: isDarkMode,
        );
      },
    );
  }
}

class GalleryItem extends StatefulWidget {
  final int index;
  final Color accentColor;
  final bool isDarkMode;

  const GalleryItem({
    super.key,
    required this.index,
    required this.accentColor,
    required this.isDarkMode,
  });

  @override
  State<GalleryItem> createState() => _GalleryItemState();
}

class _GalleryItemState extends State<GalleryItem> {
  bool _isHovered = false;

  // Nombres reales de tus archivos GIF
  final List<String> _gifNames = [
    'NeuralNetwork.gif',
    'Blockchain.gif',
    'QuantumComputing.gif',
    'Cybersecurity.gif',
    'DigitalMatrix.gif',
    'DataVisualization.gif',
    'digitalSamurai.gif',
    'CloudComputing.gif',
    'Infrastructure.gif',
  ];

  final List<String> _designTitles = [
    'Neural Network',
    'Blockchain',
    'Quantum Computing',
    'Cyber Security',
    'Digital Matrix',
    'Data Visualization',
    'Digital Samurai',
    'Cloud Computing',
    'Infrastructure',
  ];

  // Colores de placeholder para cada imagen (fallback si no existe el GIF)
  final List<List<Color>> _gradients = [
    [Color(0xFF6366F1), Color(0xFF8B5CF6)], // Neural Network - Purple
    [Color(0xFFEC4899), Color(0xFFF43F5E)], // Blockchain - Pink/Red
    [Color(0xFF14B8A6), Color(0xFF06B6D4)], // Quantum - Teal/Cyan
    [Color(0xFFF59E0B), Color(0xFFEF4444)], // Cybersecurity - Orange/Red
    [Color(0xFF8B5CF6), Color(0xFFEC4899)], // Digital Matrix - Purple/Pink
    [Color(0xFF06B6D4), Color(0xFF6366F1)], // Data Viz - Cyan/Blue
    [Color(0xFFEF4444), Color(0xFFF59E0B)], // Samurai - Red/Orange
    [Color(0xFF10B981), Color(0xFF14B8A6)], // Cloud - Green/Teal
    [Color(0xFFF43F5E), Color(0xFF8B5CF6)], // Infrastructure - Pink/Purple
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CarouselView(
              initialIndex: widget.index,
              accentColor: widget.accentColor,
              isDarkMode: widget.isDarkMode,
              gifNames: _gifNames,
              designTitles: _designTitles,
              gradients: _gradients,
            ),
          ),
        );
      },
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          transform: Matrix4.identity()
            ..translate(0.0, _isHovered ? -8.0 : 0.0),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: _gradients[widget.index],
            ),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: _gradients[widget.index][0].withOpacity(_isHovered ? 0.6 : 0.3),
                blurRadius: _isHovered ? 20 : 10,
                spreadRadius: _isHovered ? 2 : 0,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Intenta cargar el GIF, si falla muestra el gradiente
                Image.asset(
                  'assets/animations/${_gifNames[widget.index]}',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    // Si el GIF no existe, muestra el ícono sobre el gradiente
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.wallpaper,
                            size: 48,
                            color: Colors.white.withOpacity(0.9),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _designTitles[widget.index].toUpperCase(),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              letterSpacing: 2,
                              fontFamily: 'Courier',
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                // Overlay con título
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    transform: Matrix4.identity()
                      ..translate(0.0, _isHovered ? 0.0 : 100.0),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black.withOpacity(0.8),
                        ],
                      ),
                    ),
                    child: Text(
                      _designTitles[widget.index].toUpperCase(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        letterSpacing: 2,
                        fontFamily: 'Courier',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CarouselView extends StatefulWidget {
  final int initialIndex;
  final Color accentColor;
  final bool isDarkMode;
  final List<String> gifNames;
  final List<String> designTitles;
  final List<List<Color>> gradients;

  const CarouselView({
    super.key,
    required this.initialIndex,
    required this.accentColor,
    required this.isDarkMode,
    required this.gifNames,
    required this.designTitles,
    required this.gradients,
  });

  @override
  State<CarouselView> createState() => _CarouselViewState();
}

class _CarouselViewState extends State<CarouselView>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  int? _flippedIndex;
  bool _isReversed = false;
  double _speed = 1.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 35),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleFlip(int index) {
    setState(() {
      if (_flippedIndex == index) {
        _flippedIndex = null;
      } else {
        _flippedIndex = index;
      }
    });
  }

  void _toggleDirection() {
    setState(() {
      _isReversed = !_isReversed;
    });
  }

  void _changeSpeed(bool fast) {
    setState(() {
      _speed = fast ? 2.0 : 1.0;
      _controller.duration = Duration(seconds: fast ? 17 : 35);
      if (_controller.isAnimating) {
        _controller
          ..stop()
          ..repeat();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Carousel 3D
          Center(
            child: SizedBox(
              height: 400,
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.001)
                      ..rotateY((_isReversed ? -1 : 1) *
                          _controller.value *
                          2 *
                          math.pi *
                          _speed),
                    child: child,
                  );
                },
                child: Stack(
                  alignment: Alignment.center,
                  children: List.generate(9, (index) {
                    final angle = (2 * math.pi / 9) * index;
                    final radius = 300.0;
                    final x = radius * math.sin(angle);
                    final z = radius * math.cos(angle);

                    return Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.identity()
                        ..setEntry(3, 2, 0.001)
                        ..translate(x, 0.0, z)
                        ..rotateY(-angle),
                      child: CarouselCard(
                        index: index,
                        isFlipped: _flippedIndex == index,
                        onTap: () => _toggleFlip(index),
                        gifName: widget.gifNames[index],
                        designTitle: widget.designTitles[index],
                        gradient: widget.gradients[index],
                      ),
                    );
                  }),
                ),
              ),
            ),
          ),

          // Controls
          Positioned(
            top: 50,
            right: 20,
            child: Column(
              children: [
                // Close button
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white, size: 32),
                  onPressed: () => Navigator.pop(context),
                ),
                const SizedBox(height: 20),
                // Reverse direction
                IconButton(
                  icon: Icon(
                    _isReversed ? Icons.rotate_left : Icons.rotate_right,
                    color: widget.accentColor,
                    size: 28,
                  ),
                  onPressed: _toggleDirection,
                ),
                const SizedBox(height: 10),
                // Speed controls
                Column(
                  children: [
                    ElevatedButton(
                      onPressed: () => _changeSpeed(false),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _speed == 1.0
                            ? widget.accentColor
                            : Colors.grey.shade800,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                      ),
                      child: const Text('SLOW'),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () => _changeSpeed(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _speed == 2.0
                            ? widget.accentColor
                            : Colors.grey.shade800,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                      ),
                      child: const Text('FAST'),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Title
          Positioned(
            top: 50,
            left: 20,
            child: Text(
              'MODURUWALL',
              style: TextStyle(
                color: widget.accentColor,
                fontSize: 32,
                fontWeight: FontWeight.w300,
                letterSpacing: 6,
                fontFamily: 'Courier',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CarouselCard extends StatefulWidget {
  final int index;
  final bool isFlipped;
  final VoidCallback onTap;
  final String gifName;
  final String designTitle;
  final List<Color> gradient;

  const CarouselCard({
    super.key,
    required this.index,
    required this.isFlipped,
    required this.onTap,
    required this.gifName,
    required this.designTitle,
    required this.gradient,
  });

  @override
  State<CarouselCard> createState() => _CarouselCardState();
}

class _CarouselCardState extends State<CarouselCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _flipController;
  late Animation<double> _flipAnimation;

  @override
  void initState() {
    super.initState();
    _flipController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _flipAnimation = Tween<double>(begin: 0, end: math.pi).animate(
      CurvedAnimation(parent: _flipController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(CarouselCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isFlipped != oldWidget.isFlipped) {
      if (widget.isFlipped) {
        _flipController.forward();
      } else {
        _flipController.reverse();
      }
    }
  }

  @override
  void dispose() {
    _flipController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _flipAnimation,
        builder: (context, child) {
          final angle = _flipAnimation.value;
          final transform = Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateY(angle);

          return Transform(
            alignment: Alignment.center,
            transform: transform,
            child: Container(
              width: 200,
              height: 300,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: widget.gradient,
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: widget.gradient[0].withOpacity(0.5),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: angle < math.pi / 2
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          // Intenta cargar el GIF
                          Image.asset(
                            'assets/animations/${widget.gifName}',
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              // Si falla, muestra el gradiente con ícono
                              return Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.wallpaper,
                                      size: 64,
                                      color: Colors.white.withOpacity(0.9),
                                    ),
                                    const SizedBox(height: 16),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 20),
                                      child: Text(
                                        widget.designTitle.toUpperCase(),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                          letterSpacing: 2,
                                          fontFamily: 'Courier',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ],
                      )
                    : Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()..rotateY(math.pi),
                        child: Container(
                          color: Colors.black.withOpacity(0.9),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.info_outline,
                                  size: 48,
                                  color: Colors.white.withOpacity(0.9),
                                ),
                                const SizedBox(height: 16),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 20),
                                  child: Column(
                                    children: [
                                      Text(
                                        widget.designTitle.toUpperCase(),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.9),
                                          fontSize: 13,
                                          letterSpacing: 2,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Courier',
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Wallpaper animado\nGenerado con IA',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.7),
                                          fontSize: 10,
                                          fontFamily: 'Courier',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
              ),
            ),
          );
        },
      ),
    );
  }
}
